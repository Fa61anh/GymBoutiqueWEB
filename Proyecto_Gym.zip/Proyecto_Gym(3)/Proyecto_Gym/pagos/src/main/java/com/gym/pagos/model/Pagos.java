package com.gym.pagos.model;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "pagos")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pagos 
{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pago")
    private Integer id_pago;

    @Column(name = "rut_alumno", length = 10, nullable = false)
    private String runAlumno;

    @Column(name = "cod_membresia", length = 10, nullable = false)
    private String idMembresia;

    @Column(name = "monto", nullable = false)
    private Integer monto;

    @Column(name = "fecha_pago")
    private LocalDate fechaPago;

    @Column(name = "metodo_pago", length = 50, nullable = false)
    private String metodoPago;

    @Column(name = "estado_pago", length = 20, nullable = false)
    private String estadoPago;

    @Transient
    private Object datosAlumno;

    @Transient
    private Object datosMembresia;
}
