package com.gym.pagos.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gym.pagos.model.Pagos;

@Repository
public interface PagosRepository extends JpaRepository<Pagos, Integer>

{

}
