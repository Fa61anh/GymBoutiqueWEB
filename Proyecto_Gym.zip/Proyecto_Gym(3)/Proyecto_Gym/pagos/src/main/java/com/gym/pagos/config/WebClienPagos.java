package com.gym.pagos.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClienPagos
{
@Bean
    public WebClient.Builder WebClientBuilder()
    {
        return WebClient.builder();
    }
}
