package com.gym.pagos.service;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.gym.pagos.model.Pagos;
import com.gym.pagos.repository.PagosRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class PagosService 
{
 @Autowired
    private PagosRepository rp;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public Pagos guardarPago(Pagos pago) 
    {
        if (pago.getId_pago() == null) 
        {
            pago.setFechaPago(LocalDate.now());
            pago.setEstadoPago("PAGADO");
        }

        try 
        {
            Object alumno = webClientBuilder.build()
                .get()
                .uri("http://localhost:9097/api/v1/alumnos/" + pago.getRunAlumno())
                .retrieve()
                .bodyToMono(Object.class)
                .block();

            if (alumno == null) 
            {
                throw new RuntimeException("Alumno no existe");
            }

            Object membresia = webClientBuilder.build()
            .get()
            .uri("http://localhost:9095/api/v1/membresias/completa/" + pago.getIdMembresia())
            .retrieve()
            .bodyToMono(Object.class)
            .block();
            if (membresia == null) 
            {
                throw new RuntimeException("Membresía no existe");
            }

            pago.setDatosAlumno(alumno);
            pago.setDatosMembresia(membresia);

        } 
        catch (Exception e) 
        {
            throw new RuntimeException("Error de validación: " + e.getMessage());
        }

        return rp.save(pago);
    }

    public Pagos obtenerPago(Integer id) 
    {
        Pagos pago = rp.findById(id).orElse(null);

        if (pago != null) 
        {
            return enriquecerPago(pago);
        }

        return null;
    }

    private Pagos enriquecerPago(Pagos pago) 
    {
        try 
        {
            Object alumno = webClientBuilder.build()
                .get()
                .uri("http://localhost:9097/api/v1/alumnos/" + pago.getRunAlumno())
                .retrieve()
                .bodyToMono(Object.class)
                .block();

            pago.setDatosAlumno(alumno);


            Object membresia = webClientBuilder.build()
             .get()
             .uri("http://localhost:9095/api/v1/membresias/completa/" + pago.getIdMembresia())
             .retrieve()
             .bodyToMono(Object.class)
             .block();

             pago.setDatosMembresia(membresia);

        } 
        

        catch (Exception e) 
        {
            System.err.println("Error enriqueciendo pago: " + e.getMessage());
        }

        return pago;
    }

    public List<Pagos> listarTodo() 
    {
        List<Pagos> lista = rp.findAll();

        return lista.stream()
            .map(this::enriquecerPago)
            .toList();
    }

    public Pagos guardar(Pagos pago) 
    {
        return rp.save(pago);
    }

    public void eliminarPago(Integer id) 
    {
        rp.deleteById(id);
    }
}
