package com.gym.pagos.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.gym.pagos.model.Pagos;
import com.gym.pagos.service.PagosService;

@RestController
@RequestMapping("/api/v1/pagos/")
public class PagosController
{
 @Autowired
    private PagosService pagosService;

    @PostMapping
    public Pagos crear(@RequestBody Pagos pago)
    {
        return pagosService.guardarPago(pago);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pagos> obtenerPago(@PathVariable Integer id) 
    {
        Pagos pago = pagosService.obtenerPago(id);

        return pago != null
            ? ResponseEntity.ok(pago)
            : ResponseEntity.notFound().build();
    }

    @GetMapping
    public List<Pagos> listar() 
    {
        return pagosService.listarTodo();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) 
    {
        pagosService.eliminarPago(id);

        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Pagos> actualizar(@PathVariable Integer id,
                                            @RequestBody Pagos pagoActualizado) 
    {
        Pagos pagoExistente = pagosService.obtenerPago(id);

        if (pagoExistente == null) 
        {
            return ResponseEntity.notFound().build();
        }

        if (pagoActualizado.getRunAlumno() != null) 
        {
            pagoExistente.setRunAlumno(pagoActualizado.getRunAlumno());
        }

        if (pagoActualizado.getIdMembresia() != null) 
        {
            pagoExistente.setIdMembresia(pagoActualizado.getIdMembresia());
        }

        if (pagoActualizado.getMonto() > 0) 
        {
            pagoExistente.setMonto(pagoActualizado.getMonto());
        }

        if (pagoActualizado.getMetodoPago() != null) 
        {
            pagoExistente.setMetodoPago(pagoActualizado.getMetodoPago());
        }

        if (pagoActualizado.getEstadoPago() != null) 
        {
            pagoExistente.setEstadoPago(pagoActualizado.getEstadoPago());
        }

        Pagos guardado = pagosService.guardarPago(pagoExistente);

        return ResponseEntity.ok(guardado);
    }

}