package com.gym.service_auth.repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gym.service_auth.model.Rol;

@Repository
public interface RolRepository extends JpaRepository<Rol, Long>
 {
    Optional<Rol> findByNombreRol(String nombreRol);

}
