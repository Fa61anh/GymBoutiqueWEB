package com.gym.service_auth.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;

import com.gym.service_auth.dto.AuthRequest;

import com.gym.service_auth.service.AuthService;

@RestController
@RequestMapping("/auth")
@Tag(name = "Autentication", description = "Endpoints para registro y loguin de usuarios")

public class AutenticacionController 
{

    @Autowired
    private AuthService authService;

    @Operation(summary = "Registrar un nuevo usuario", description = "Guarda el usuario mapeando sus roles desde el DTO")
    
    @PostMapping("/registrar")
    public ResponseEntity<String> registrar(@RequestBody AuthRequest request)
   {
    try {
        return ResponseEntity.ok(authService.registrar(request));
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
    }
   }

    @Operation(summary = "Iniciar sesión", description = "Retorna el Token JWT si las credenciales son válidas")
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody AuthRequest request)
    {
        try {
            String token = authService.login(request.getNombreUsuario(), request.getContrasena());
            return ResponseEntity.ok(token);
        }
        catch(RuntimeException e)
        {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }
}
