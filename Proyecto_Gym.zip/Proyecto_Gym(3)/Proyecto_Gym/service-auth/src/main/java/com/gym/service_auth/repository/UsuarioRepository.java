package com.gym.service_auth.repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gym.service_auth.model.Usuarios;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuarios, Long>
{
    Optional<Usuarios>findByNombreUsuario(String nombreUsuario);
}
