package com.gym.service_auth.dto;
import lombok.AllArgsConstructor;
import java.util.Set;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthRequest
 
{
    private String nombreUsuario;
    private String contrasena;
    private String correo;


    private Set<String> roles;
}
