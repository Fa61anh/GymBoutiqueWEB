package com.gym.boutique.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "alumnos")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Alumnos 
{
    @Id
    @Column(unique = true, name = "rut", length = 10, nullable = false)
    private String run;

    @Column(unique = false, name = "nombres", length = 100, nullable = false)
    private String nomb;

    @Column(unique = false, name = "apellidos", length = 100, nullable = false)
    private String apell;

    @Column(unique = true, length = 100, nullable = false)
    private String correo; 

    @Column(unique = true, name = "numero_celular", length = 15, nullable = false)
    private String numero; 

    @Column(unique = true, name = "numero_celular_respaldo", length = 15, nullable = false)
    private String numrespaldo; 

    @Column(name = "fecha_nacimiento")
    private LocalDate fechaNacimiento;

    @Column(unique = false, name = "objetivo_del_entrenamiento", length = 500, nullable = false)
    private String obj;

    @Column(unique = false, length = 500, nullable = false)
    private String direccion;
}
