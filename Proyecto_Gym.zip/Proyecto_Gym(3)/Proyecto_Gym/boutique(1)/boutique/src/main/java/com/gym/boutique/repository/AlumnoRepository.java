package com.gym.boutique.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.gym.boutique.model.Alumnos;

public interface AlumnoRepository extends JpaRepository<Alumnos,String>
{

}
