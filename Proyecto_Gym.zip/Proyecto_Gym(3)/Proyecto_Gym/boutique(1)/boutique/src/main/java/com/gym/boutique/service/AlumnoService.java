package com.gym.boutique.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gym.boutique.model.Alumnos;
import com.gym.boutique.repository.AlumnoRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class AlumnoService 
{
    @Autowired
    private AlumnoRepository rp;
    public List<Alumnos> listarTodosAlumnos()
    {
        return rp.findAll();
    }

    public Alumnos guardar(Alumnos alumnos)
    {
        return rp.save(alumnos);
    }

    public Alumnos buscarPorRun(String run)
    {
        return rp.findById(run).orElse(null); 
    }

    public void eliminar(String run)
    {
        rp.deleteById(run);
    }

}
