package com.gym.boutique.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.gym.boutique.model.Alumnos;
import com.gym.boutique.service.AlumnoService;

@RestController
@RequestMapping("/api/v1/alumnos/")
public class AlumnoController 
{
    @Autowired
    private AlumnoService service;

    @GetMapping
    public ResponseEntity<List<Alumnos>> listar()
    {
        List<Alumnos> alumnos = service.listarTodosAlumnos();
        return new ResponseEntity<>(alumnos, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Alumnos> crear (@RequestBody Alumnos alumnos)
    {
        return new ResponseEntity<>(service.guardar(alumnos),HttpStatus.CREATED);
    }
    
    @GetMapping("/{run}")
    public ResponseEntity<Alumnos> obtenerPorRun(@PathVariable String run)
    {
        Alumnos alumnos = service.buscarPorRun(run);
        if(alumnos == null) 
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(alumnos,HttpStatus.OK);
    }
    
    @PutMapping("/{run}")
    public ResponseEntity<Alumnos> actualizar(@PathVariable String run, @RequestBody Alumnos alumnos)
    {
        Alumnos existente = service.buscarPorRun(run);
        if(existente == null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        alumnos.setRun(run);
        return new ResponseEntity<>(service.guardar(alumnos), HttpStatus.OK);
    }

    @DeleteMapping("/{run}")
    public ResponseEntity<Void> eliminar(@PathVariable String run)
    {
        service.eliminar(run);;
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
