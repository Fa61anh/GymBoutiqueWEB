package com.gym.boutique.service_alumno;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import com.gym.boutique.model.Alumnos;
import com.gym.boutique.repository.AlumnoRepository;
import com.gym.boutique.service.AlumnoService;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AlumnoServiceTest {
    @Mock
    private AlumnoRepository alumnoRepository;
    @InjectMocks
    private AlumnoService alumnoService;
    @Test
    @DisplayName("Deberia crear un alumno correctamente")
    void guardarAlumnoTest(){
        Alumnos alumno = new Alumnos();
        alumno.setNomb("Juan");
        alumno.setApell("Alarcon");
        alumno.setRun("31643872-4");
        alumno.setNumero("+56989562409");
        alumno.setNumrespaldo("+56958492037");
        
        Mockito.when(alumnoRepository.save(any(Alumnos.class))).thenReturn(alumno);
        Alumnos resultado = alumnoService.guardar(alumno);
        assertNotNull(resultado);
        assertEquals("Juan", resultado.getNomb());
        assertEquals("Alarcon", resultado.getApell());
        assertEquals("31643872-4", resultado.getRun());
        assertEquals("+56989562409", resultado.getNumero());
        assertEquals("+56958492037", resultado.getNumrespaldo());

        verify(alumnoRepository, times(1)).save(alumno);

    }

}
