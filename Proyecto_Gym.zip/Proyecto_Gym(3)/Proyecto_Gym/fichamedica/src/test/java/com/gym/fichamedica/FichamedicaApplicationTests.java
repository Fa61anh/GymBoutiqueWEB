package com.gym.fichamedica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FichamedicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
