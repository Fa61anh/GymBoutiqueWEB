package com.gym.fichamedica.service_ficha;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.gym.fichamedica.model.AlumnosDTO;
import com.gym.fichamedica.model.FichaMedica;
import com.gym.fichamedica.repository.FichaMedicaRepository;
import com.gym.fichamedica.service.FichaMedicaService;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class FichaServiceTest {
    @Mock
    private FichaMedicaRepository fichaRepository;
    @Mock
    private WebClient.Builder webClientBuilder;
    @InjectMocks
    private FichaMedicaService fichaService;
    @Test
    void obtenerSucursalCompletaTest(){
    
        String FichaId= "23456789-1";
        String AlumnoId = "23456789-1";


        FichaMedica fichaMock = new FichaMedica();
        fichaMock.setRun(FichaId);
        fichaMock.setRun(AlumnoId);

        AlumnosDTO alumnoMock = new AlumnosDTO();
        alumnoMock.setRun(AlumnoId);
        alumnoMock.setNomb("Lamine");

        when(fichaRepository.findById(FichaId)).thenReturn(Optional.of(fichaMock));

        WebClient webClient = Mockito.mock(WebClient.class);
        WebClient.RequestHeadersUriSpec uriSpec = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec headersSpec = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = Mockito.mock(WebClient.ResponseSpec.class);

        when(webClientBuilder.build()).thenReturn(webClient);
        when(webClient.get()).thenReturn(uriSpec);
        when(uriSpec.uri(anyString())).thenReturn(headersSpec);
        when(headersSpec.retrieve()).thenReturn(responseSpec);
        
        when(responseSpec.bodyToMono(Object.class)).thenReturn(Mono.just(alumnoMock));

    
        FichaMedica resultado = fichaService.buscarPorRun(FichaId);
        assertNotNull(resultado, "La ficha no debe ser nula");
        assertNotNull(resultado.getDatosAlumno(), "Los datos del alumno deben estar presentes");
        
    
        AlumnosDTO datosRetornados = (AlumnosDTO) resultado.getDatosAlumno();
        assertEquals("Lamine", datosRetornados.getNomb(), "El nombre del alumno debe coincidir con el simulado");
        assertEquals(AlumnoId, datosRetornados.getRun());

        verify(fichaRepository, times(1)).findById(FichaId);
    }
}
