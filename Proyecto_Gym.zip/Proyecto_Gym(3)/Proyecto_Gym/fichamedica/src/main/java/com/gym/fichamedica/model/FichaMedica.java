package com.gym.fichamedica.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ficha_medica")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FichaMedica 
{
  @Id
  @Column(unique = true, name = "rut", length = 10, nullable = false)
  private String run;
 
  @Column(unique = false, name = "nombres", length = 100, nullable = false)
  private String nombres;

  @Column(unique = false, name = "apellidos", length = 100, nullable = false)
  private String apellidos;

  @Column(unique = true, name = "numero_celular", length = 15, nullable = false)
  private String numero;

  @Column(unique = false, name = "alergias_previas", length = 4, nullable = false)
  private String alergiasPrevias;    
  
  @Column(unique = false, name = "tipo_alergia", length = 500, nullable = false)
  private String tipoAlergia;

  @Column(unique = false, name = "lesiones_previas", length = 4, nullable = false)
  private String lesionesPrevias;
  
  @Column(unique = false, name = "tipo_lesion", length = 500, nullable = false)
  private String tipoLesion;

    @Transient
    private Object datosAlumno;
}
