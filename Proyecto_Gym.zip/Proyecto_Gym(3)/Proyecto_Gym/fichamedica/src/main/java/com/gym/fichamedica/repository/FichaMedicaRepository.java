package com.gym.fichamedica.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gym.fichamedica.model.FichaMedica;

@Repository
public interface FichaMedicaRepository extends JpaRepository<FichaMedica, String>
 {

}
