package com.gym.fichamedica.controller;
import com.gym.fichamedica.model.FichaMedica;
import com.gym.fichamedica.service.FichaMedicaService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/fichas/")
public class FichaMedicaController 
{
 @Autowired
    private FichaMedicaService fichaService;

    @PostMapping
    public FichaMedica crear(@RequestBody FichaMedica ficha)
    {
        return fichaService.guardarFicha(ficha);
    }

    @GetMapping("/{run}")
    public ResponseEntity<FichaMedica> obtenerFicha(@PathVariable String run) 
    {
        FichaMedica ficha = fichaService.buscarPorRun(run);

        return ficha != null
            ? ResponseEntity.ok(ficha)
            : ResponseEntity.notFound().build();
    }

    @GetMapping
    public List<FichaMedica> listar() 
    {
        return fichaService.listarTodo();
    }

    @DeleteMapping("/{run}")
    public ResponseEntity<Void> eliminar(@PathVariable String run) 
    {
        fichaService.eliminarFicha(run);

        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{run}")
    public ResponseEntity<FichaMedica> actualizar(@PathVariable String run,
    @RequestBody FichaMedica fichaActualizada) 
    {
        FichaMedica fichaExistente = fichaService.buscarPorRun(run);

        if (fichaExistente == null) 
        {
            return ResponseEntity.notFound().build();
        }

        if (fichaActualizada.getNombres() != null) 
        {
            fichaExistente.setNombres(fichaActualizada.getNombres());
        }

        if (fichaActualizada.getApellidos() != null) 
        {
            fichaExistente.setApellidos(fichaActualizada.getApellidos());
        }

        if (fichaActualizada.getNumero() != null) 
        {
            fichaExistente.setNumero(fichaActualizada.getNumero());
        }

        if (fichaActualizada.getAlergiasPrevias() != null) 
        {
            fichaExistente.setAlergiasPrevias(fichaActualizada.getAlergiasPrevias());
        }

        if (fichaActualizada.getTipoAlergia() != null) 
        {
            fichaExistente.setTipoAlergia(fichaActualizada.getTipoAlergia());
        }

        if (fichaActualizada.getLesionesPrevias() != null) 
        {
            fichaExistente.setLesionesPrevias(fichaActualizada.getLesionesPrevias());
        }

        if (fichaActualizada.getTipoLesion() != null) 
        {
            fichaExistente.setTipoLesion(fichaActualizada.getTipoLesion());
        }

        FichaMedica guardada = fichaService.guardarFicha(fichaExistente);

        return ResponseEntity.ok(guardada);
    }
}
