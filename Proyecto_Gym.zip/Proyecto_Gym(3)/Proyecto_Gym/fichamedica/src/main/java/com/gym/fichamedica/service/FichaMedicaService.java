package com.gym.fichamedica.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.gym.fichamedica.model.FichaMedica;
import com.gym.fichamedica.repository.FichaMedicaRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class FichaMedicaService 
{
 @Autowired
    private FichaMedicaRepository rp;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public FichaMedica guardarFicha(FichaMedica ficha) 
    {
        try 
        {
            Object alumno = webClientBuilder.build()
                .get()
                .uri("http://localhost:9097/api/v1/alumnos/" + ficha.getRun())
                .retrieve()
                .bodyToMono(Object.class)
                .block();

            if (alumno == null) 
            {
                throw new RuntimeException("Alumno no existe");
            }

            ficha.setDatosAlumno(alumno);

        } 
        catch (Exception e) 
        {
            throw new RuntimeException("Error de validación: " + e.getMessage());
        }

        return rp.save(ficha);
    }

    public FichaMedica buscarPorRun(String run) 
    {
        FichaMedica ficha = rp.findById(run).orElse(null);

        if (ficha != null) 
        {
            return enriquecerFicha(ficha);
        }

        return null;
    }

    private FichaMedica enriquecerFicha(FichaMedica ficha) 
    {
        try 
        {
            Object alumno = webClientBuilder.build()
                .get()
                .uri("http://localhost:9097/api/v1/alumnos/" + ficha.getRun())
                .retrieve()
                .bodyToMono(Object.class)
                .block();

            ficha.setDatosAlumno(alumno);

        } 
        catch (Exception e) 
        {
            System.err.println("Error enriqueciendo ficha médica: " + e.getMessage());
        }

        return ficha;
    }

    public List<FichaMedica> listarTodo() 
    {
        List<FichaMedica> lista = rp.findAll();

        return lista.stream()
            .map(this::enriquecerFicha)
            .toList();
    }

    public void eliminarFicha(String run) 
    {
        rp.deleteById(run);
    }
}
