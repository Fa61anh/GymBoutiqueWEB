package service_ubicacion;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import com.gym.ubicacion.model.Ubicacion;
import com.gym.ubicacion.repository.UbicacionRepository;
import com.gym.ubicacion.service.UbicacionService;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UbicacionServiceTest {
    @Mock
    private UbicacionRepository ubicacionRepository;
    @InjectMocks
    private UbicacionService ubicacionService;
    @Test
    @DisplayName("Deberia crear una ubicacion correctamente")
    void guardarUbicacionTest(){
        Ubicacion ubicacion = new Ubicacion();
        ubicacion.setCodComuna(892);
        ubicacion.setDireccion("Av. Los Pajaritos 2689, 9250749 Maipú, Región Metropolitana");
        ubicacion.setNombreComuna("Maipu");
        
        Mockito.when(ubicacionRepository.save(any(Ubicacion.class))).thenReturn(ubicacion);
        Ubicacion resultado = ubicacionService.guardarUbicacion(ubicacion);
        assertNotNull(resultado);
        assertEquals(892, resultado.getCodComuna());
        assertEquals("Av. Los Pajaritos 2689, 9250749 Maipú, Región Metropolitana", resultado.getDireccion());
        assertEquals("Maipu", resultado.getNombreComuna());

        verify(ubicacionRepository, times(1)).save(ubicacion);
    }

}
