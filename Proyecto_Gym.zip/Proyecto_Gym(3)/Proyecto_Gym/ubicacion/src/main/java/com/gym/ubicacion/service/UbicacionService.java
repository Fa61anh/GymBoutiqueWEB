package com.gym.ubicacion.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gym.ubicacion.model.Ubicacion;
import com.gym.ubicacion.repository.UbicacionRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UbicacionService 
{
  @Autowired
    private UbicacionRepository rp;

    public Ubicacion guardarUbicacion(Ubicacion ubicacion)
    {
        return rp.save(ubicacion);
    }

    public Ubicacion buscarPorId(Integer codComuna)
    {
        return rp.findById(codComuna).orElse(null);
    }

    public List<Ubicacion> listar()
    {
        return rp.findAll();
    }

    public void eliminarUbicacion(Integer codComuna)
    {
        rp.deleteById(codComuna);
    }
}

