package com.gym.ubicacion.controller;
import com.gym.ubicacion.model.Ubicacion;
import com.gym.ubicacion.service.UbicacionService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/ubicaciones/")
public class UbicacionController 
{
 @Autowired
    private UbicacionService ubicacionService;

    @PostMapping
    public Ubicacion crear(@RequestBody Ubicacion ubicacion)
    {
        return ubicacionService.guardarUbicacion(ubicacion);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Ubicacion> obtenerUbicacion(@PathVariable Integer id) 
    {
        Ubicacion ubicacion = ubicacionService.buscarPorId(id);

        return ubicacion != null
            ? ResponseEntity.ok(ubicacion)
            : ResponseEntity.notFound().build();
    }

    @GetMapping
    public List<Ubicacion> listar() 
    {
        return ubicacionService.listar();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) 
    {
        ubicacionService.eliminarUbicacion(id);

        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Ubicacion> actualizar(@PathVariable Integer id,
                                                @RequestBody Ubicacion ubicacionActualizada) 
    {
        Ubicacion ubicacionExistente = ubicacionService.buscarPorId(id);

        if (ubicacionExistente == null) 
        {
            return ResponseEntity.notFound().build();
        }

        if (ubicacionActualizada.getNombreComuna() != null) 
        {
            ubicacionExistente.setNombreComuna(ubicacionActualizada.getNombreComuna());
        }

        if (ubicacionActualizada.getDireccion() != null) 
        {
            ubicacionExistente.setDireccion(ubicacionActualizada.getDireccion());
        }

        Ubicacion guardada = ubicacionService.guardarUbicacion(ubicacionExistente);

        return ResponseEntity.ok(guardada);
    }
}
