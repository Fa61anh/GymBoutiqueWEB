package com.gym.ubicacion.model;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ubicacion")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Ubicacion
{
  @Id
    private Integer codComuna;

    private String nombreComuna;
    private String direccion;
}
