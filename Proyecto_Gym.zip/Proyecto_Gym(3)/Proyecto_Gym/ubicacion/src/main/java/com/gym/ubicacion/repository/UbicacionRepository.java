package com.gym.ubicacion.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gym.ubicacion.model.Ubicacion;

@Repository

public interface UbicacionRepository extends JpaRepository<Ubicacion, Integer>
 {

}
