package service_clases;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.gym.clases.model.Clases;
import com.gym.clases.model.InstructorDTO;
import com.gym.clases.repository.ClasesRepository;
import com.gym.clases.service.ClasesService;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class ClasesServiceTest {
    @Mock
    private ClasesRepository clasesRepository;
    @Mock
    private WebClient.Builder webClientBuilder;
    @InjectMocks
    private ClasesService clasesService;
    @Test
    void obtenerSucursalCompletaTest(){
   
        Long ClaseId= 1L;
        String instructorId = "12345678-9";


        Clases claseMock = new Clases();
        claseMock.setIdClase(ClaseId);
        claseMock.setRut(instructorId);;

        InstructorDTO instructorMock = new InstructorDTO();
        instructorMock.setRun(instructorId);
        instructorMock.setNomb("Lamine");
 
        when(clasesRepository.findById(ClaseId)).thenReturn(Optional.of(claseMock));

        WebClient webClient = Mockito.mock(WebClient.class);
        WebClient.RequestHeadersUriSpec uriSpec = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec headersSpec = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = Mockito.mock(WebClient.ResponseSpec.class);

        when(webClientBuilder.build()).thenReturn(webClient);
        when(webClient.get()).thenReturn(uriSpec);
        when(uriSpec.uri(anyString())).thenReturn(headersSpec);
        when(headersSpec.retrieve()).thenReturn(responseSpec);
        
        when(responseSpec.bodyToMono(any(Class.class))).thenReturn(Mono.just(instructorMock));
    
        Clases resultado = clasesService.buscarPorId(ClaseId);
        assertNotNull(resultado, "La clase no debe ser nula");
        assertNotNull(resultado.getDatosInstructor(), "Los datos del instructor deben estar presentes");
        
    
        InstructorDTO datosRetornados = (InstructorDTO) resultado.getDatosInstructor();
        assertEquals("Lamine", datosRetornados.getNomb(), "El nombre del instructor debe coincidir con el simulado");
        assertEquals(instructorId, datosRetornados.getRun());

        verify(clasesRepository, times(1)).findById(ClaseId);
    }
}
