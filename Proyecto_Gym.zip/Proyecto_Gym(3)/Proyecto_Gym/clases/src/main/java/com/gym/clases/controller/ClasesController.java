package com.gym.clases.controller;
import com.gym.clases.model.Clases;
import com.gym.clases.service.ClasesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/clases/")
public class ClasesController 
{
@Autowired
    private ClasesService clasesService;

    @PostMapping
    public Clases crear(@RequestBody Clases clase)
    {
        return clasesService.guardarClases(clase);
    }
    @GetMapping("{id}")
    public ResponseEntity<Clases> obtenerClase(@PathVariable Long id) {
       Clases clase = clasesService.buscarPorId(id);
       return clase != null ? ResponseEntity.ok(clase) : ResponseEntity.notFound().build();
     }

    @GetMapping
    public List<Clases> listar() {
        return clasesService.listar();
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        clasesService.eliminarClase(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/actualizar/{id}")
    public ResponseEntity<Clases> actualizar(@PathVariable Long id, @RequestBody Clases claseActualizada) {
    
        Clases claseExistente = clasesService.buscarPorId(id);
    
    if (claseExistente == null) {
        return ResponseEntity.notFound().build(); 
    }

    if (claseActualizada.getTipoClase() != null) {
        claseExistente.setTipoClase(claseActualizada.getTipoClase());
    }
    
    if (claseActualizada.getHorario() != null) {
        claseExistente.setHorario(claseActualizada.getHorario());
    }
    
    if (claseActualizada.getCupos() > 0) {
        claseExistente.setCupos(claseActualizada.getCupos());
    }
    
    if (claseActualizada.getRut() != null) {
        claseExistente.setRut(claseActualizada.getRut());
    }
    
   
    Clases guardada = clasesService.guardarClases(claseExistente);
    
    return ResponseEntity.ok(guardada);
}

}
