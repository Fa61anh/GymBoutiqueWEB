package com.gym.clases.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "clases")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Clases 
{
  @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_clase")
    private Long idClase;

    @NotBlank
    @Column(name = "rut_instructor", nullable = false)
    private String rut;

    @NotBlank
    @Column(name = "tipo_clase", nullable = false)
    private String tipoClase;

    @NotBlank
    @Column(name = "horario", nullable = false)
    private String horario;

    @NotNull
    @Column(name = "cupos", nullable = false)
    private int cupos;

    @Transient
    private Object datosInstructor;
}
