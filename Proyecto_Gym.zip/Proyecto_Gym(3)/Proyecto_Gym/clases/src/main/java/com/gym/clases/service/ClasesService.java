package com.gym.clases.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import com.gym.clases.model.Clases;
import com.gym.clases.repository.ClasesRepository;


@Service

public class ClasesService
{
   @Autowired
    private ClasesRepository rp;
    @Autowired
    private WebClient.Builder webClientBuilder;
   
    public Clases guardarClases(Clases clase) {

        if (clase.getRut() != null) {
            try {
                webClientBuilder.build()
                        .get()
                        .uri("http://localhost:9092/api/v1/instructor/" + clase.getRut())
                        .retrieve()
                        .bodyToMono(Object.class)
                        .block();

            } catch (Exception e) {
                 throw new RuntimeException("Instructor no encontrado"+ e.getMessage());
            }
        }

        return rp.save(clase);
    }
    public List<Clases> listar() {
        return rp.findAll();
    }
    public Clases buscarPorId(Long id) {

        Clases clase = rp.findById(id).orElse(null);
    
        if (clase != null) {
            clase = enriquecerClase(clase);
        }
     
        return clase;
    }
    public void eliminarClase(Long id) {
        rp.deleteById(id);
    }

    private Clases enriquecerClase(Clases clase) 
    {
        try 
        {
            Object instructor = webClientBuilder.build()
                .get()
                .uri("http://localhost:9092/api/v1/instructor/" + clase.getRut())
                .retrieve()
                .bodyToMono(Object.class)
                .block();

            clase.setDatosInstructor(instructor);

        } 
        catch (Exception e) 
        {
            System.err.println("Error enriqueciendo clase: " + e.getMessage());
        }

        return clase;
    }
    
}
