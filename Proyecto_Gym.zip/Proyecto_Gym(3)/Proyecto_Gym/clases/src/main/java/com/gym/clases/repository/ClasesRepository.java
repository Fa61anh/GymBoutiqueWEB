package com.gym.clases.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.gym.clases.model.Clases;
public interface ClasesRepository extends JpaRepository<Clases,Long>
{

}
