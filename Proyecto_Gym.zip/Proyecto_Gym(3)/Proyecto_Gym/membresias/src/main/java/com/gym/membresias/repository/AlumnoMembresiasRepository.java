package com.gym.membresias.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.gym.membresias.model.AlumnoMembresias;

@Repository
public interface AlumnoMembresiasRepository extends JpaRepository<AlumnoMembresias,String>
{

}
