package com.gym.membresias.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.gym.membresias.model.AlumnoMembresias;
import com.gym.membresias.repository.AlumnoMembresiasRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class AlumnoMembresiasService 
{
    @Autowired
    private AlumnoMembresiasRepository rp;
    @Autowired
    private WebClient.Builder webClientBuilder;

    public AlumnoMembresias guardarMembresia(AlumnoMembresias membresia) {

    if (membresia.getRut_comprador() != null) {
        try {
            Object alumno = webClientBuilder.build()
                .get()
                .uri("http://localhost:9097/api/v1/alumnos/" + membresia.getRut_comprador())
                .retrieve()
                .bodyToMono(Object.class)
                .block();

            membresia.setDatosAlumno(alumno);

        } catch (Exception e) {
            throw new RuntimeException("Alumno no existe o servicio no disponible"+ e.getMessage());
        }
    }

    return rp.save(membresia);
   }
  
    public AlumnoMembresias obtenerMembresiaCompleta(String id) {
        AlumnoMembresias membresia = rp.findById(id).orElse(null);
        if (membresia != null) {
            return enriquecerConAlumno(membresia);
        }
        return null;
    }

    private AlumnoMembresias enriquecerConAlumno(AlumnoMembresias membresia) 
    {
    if (membresia.getRut_comprador() != null) {
        try {
            Object alumno = webClientBuilder.build()
                .get()
                .uri("http://localhost:9097/api/v1/alumnos/" + membresia.getRut_comprador())
                .retrieve()
                .bodyToMono(Object.class) 
                .block(); 
            
            membresia.setDatosAlumno(alumno);
            
        } catch (Exception e) {
            
            System.err.println("Informacion del alumno no encontrada actualmente: " + e.getMessage());
        }
    }
    return membresia;
    }

    public List<AlumnoMembresias> listarTodasMembresias()
    {
        return rp.findAll();
    }

    public AlumnoMembresias guardar(AlumnoMembresias  alumnomembresias)
    {
        return rp.save(alumnomembresias);
    }

    public AlumnoMembresias buscarPorRun(String run)
    {
        return rp.findById(run).orElse(null); 
    }

    public void eliminar(String id)
    {
        rp.deleteById(id);
    }

}
