package com.gym.membresias.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "alumno_membresias")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AlumnoMembresias 
{
    
    @Id
    @Column(unique = true, name = "cod_membresia", length = 10, nullable = false)
    private String id;

    @Column(unique = false, name = "rut", length = 10, nullable = false)
    private String rut_comprador;

    @Column(unique = false, name = "nombre", length = 100, nullable = false)
    private String nomb;

    @Column(name = "fecha_inicio_membresia")
    private LocalDate fechaInicio;

    @Column(name = "fecha_vencimiento_membresia")
    private LocalDate fechaFin;

    @Column(unique = false, name = "Valor_membresia", length = 10, nullable = false)
    private Integer precio;

    @Transient
    private Object datosAlumno;
}
