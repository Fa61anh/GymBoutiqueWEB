package com.gym.membresias.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gym.membresias.model.AlumnoMembresias;
import com.gym.membresias.service.AlumnoMembresiasService;

@RestController
@RequestMapping("/api/v1/membresias/")
public class AlumnoMembresiasController 
{
    @Autowired
    private AlumnoMembresiasService sr;

    @PostMapping
    public ResponseEntity<?> guardarConValidacion(@RequestBody AlumnoMembresias membresia) {
        try {
            AlumnoMembresias nueva = sr.guardarMembresia(membresia);
            return ResponseEntity.status(HttpStatus.CREATED).body(nueva);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @GetMapping("/completa/{id}")
    public ResponseEntity<AlumnoMembresias> obtenerCompleta(@PathVariable String id) {
        AlumnoMembresias m = sr.obtenerMembresiaCompleta(id);
        return m != null ? ResponseEntity.ok(m) : ResponseEntity.notFound().build();
    }

    @GetMapping
    public List<AlumnoMembresias> listar() {
        return sr.listarTodasMembresias();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable String id) {
        sr.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/actualizar/{id}")
    public ResponseEntity<AlumnoMembresias> actualizar(@PathVariable String id, @RequestBody AlumnoMembresias membresiaActualizada) {
    
    AlumnoMembresias membresiaExistente = sr.obtenerMembresiaCompleta(id);
    
    if (membresiaExistente == null) {
        return ResponseEntity.notFound().build(); 
    }
    membresiaExistente.setNomb(membresiaActualizada.getNomb());
    membresiaExistente.setFechaInicio(membresiaActualizada.getFechaInicio());
    membresiaExistente.setFechaFin(membresiaActualizada.getFechaFin());
    membresiaExistente.setPrecio(membresiaActualizada.getPrecio());
    membresiaExistente.setRut_comprador(membresiaActualizada.getRut_comprador());
    
    AlumnoMembresias guardada = sr.guardarMembresia(membresiaExistente);
    
    return ResponseEntity.ok(guardada);
}
}
