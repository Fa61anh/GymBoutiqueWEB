package com.gym.sucursal.service_sucursal;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;
import com.gym.sucursal.model.Sucursal;
import com.gym.sucursal.model.UbicacionDTO;
import com.gym.sucursal.repository.SucursalRepository;
import com.gym.sucursal.service.SucursalService;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class SucursalServiceTest {
    
    @Mock
    private SucursalRepository sucursalRepository;
    @Mock
    private WebClient.Builder webClientBuilder;
    @InjectMocks
    private SucursalService sucursalService;
    @Test
    void obtenerSucursalCompletaTest(){
        Integer sucursalId = 963;
        Integer ubicacionId = 593;


        Sucursal sucursalMock = new Sucursal();
        sucursalMock.setCodSucursal(sucursalId);
        sucursalMock.setCodComuna(593);

        UbicacionDTO ubicacionMock = new UbicacionDTO();
        ubicacionMock.setCodComuna(593);
        ubicacionMock.setNombreComuna("Antofagasta");

        when(sucursalRepository.findById(sucursalId)).thenReturn(Optional.of(sucursalMock));

        WebClient webClient = Mockito.mock(WebClient.class);
        WebClient.RequestHeadersUriSpec uriSpec = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec headersSpec = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = Mockito.mock(WebClient.ResponseSpec.class);

        when(webClientBuilder.build()).thenReturn(webClient);
        when(webClient.get()).thenReturn(uriSpec);
        when(uriSpec.uri(anyString())).thenReturn(headersSpec);
        when(headersSpec.retrieve()).thenReturn(responseSpec);
        
        when(responseSpec.bodyToMono(Object.class)).thenReturn(Mono.just(ubicacionMock));

        Sucursal resultado = sucursalService.buscarPorId(sucursalId);

        assertNotNull(resultado, "La sucursal no debe ser nula");
        assertNotNull(resultado.getDatosUbicacion(), "Los datos de la ubicación deben estar presentes");
        
        UbicacionDTO datosRetornados = (UbicacionDTO) resultado.getDatosUbicacion();
        assertEquals("Antofagasta", datosRetornados.getNombreComuna(), "El nombre de la comuna debe coincidir con el simulado");
        assertEquals(ubicacionId, datosRetornados.getCodComuna());
        verify(sucursalRepository, times(1)).findById(sucursalId);
    }
}
