package com.gym.sucursal.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UbicacionDTO {
    
    private Integer codComuna;
    private String nombreComuna;
    private String direccion;

}
