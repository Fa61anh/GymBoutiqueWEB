package com.gym.sucursal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.gym.sucursal.model.Sucursal;
import com.gym.sucursal.repository.SucursalRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class SucursalService 
{
   @Autowired
    private SucursalRepository rp;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public Sucursal guardarSucursal(Sucursal sucursal) 
    {
        try 
        {
            Object ubicacion = webClientBuilder.build()
                .get()
                .uri("http://localhost:9091/api/v1/ubicaciones/" + sucursal.getCodComuna())
                .retrieve()
                .bodyToMono(Object.class)
                .block();

            if (ubicacion == null) 
            {
                throw new RuntimeException("Ubicación no existe");
            }

            sucursal.setDatosUbicacion(ubicacion);

        } 
        catch (Exception e) 
        {
            throw new RuntimeException("Error de validación: " + e.getMessage());
        }

        return rp.save(sucursal);
    }

    public Sucursal buscarPorId(Integer codSucursal) 
    {
        Sucursal sucursal = rp.findById(codSucursal).orElse(null);

        if (sucursal != null) 
        {
            return enriquecerSucursal(sucursal);
        }

        return null;
    }

    private Sucursal enriquecerSucursal(Sucursal sucursal) 
    {
        try 
        {
            Object ubicacion = webClientBuilder.build()
                .get()
                .uri("http://localhost:9091/api/v1/ubicaciones/" + sucursal.getCodComuna())
                .retrieve()
                .bodyToMono(Object.class)
                .block();

            sucursal.setDatosUbicacion(ubicacion);

        } 
        catch (Exception e) 
        {
            System.err.println("Error enriqueciendo sucursal: " + e.getMessage());
        }

        return sucursal;
    }

    public List<Sucursal> listarTodo() 
    {
        List<Sucursal> lista = rp.findAll();

        return lista.stream()
            .map(this::enriquecerSucursal)
            .toList();
    }

    public void eliminarSucursal(Integer codSucursal) 
    {
        rp.deleteById(codSucursal);
    }
}
