package com.gym.sucursal.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gym.sucursal.model.Sucursal;

@Repository
public interface SucursalRepository extends JpaRepository <Sucursal, Integer>
{

}
