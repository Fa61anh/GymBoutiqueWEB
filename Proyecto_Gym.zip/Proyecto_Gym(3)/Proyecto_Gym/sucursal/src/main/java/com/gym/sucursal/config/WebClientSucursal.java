package com.gym.sucursal.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientSucursal 
{
 @Bean
    public WebClient.Builder WebClientBuilder()
    {
        return WebClient.builder();
    }
}
