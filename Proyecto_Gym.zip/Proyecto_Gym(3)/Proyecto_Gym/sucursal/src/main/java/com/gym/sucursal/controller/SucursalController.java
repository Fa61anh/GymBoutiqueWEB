package com.gym.sucursal.controller;
import com.gym.sucursal.model.Sucursal;
import com.gym.sucursal.service.SucursalService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/sucursales/")
public class SucursalController
{
 @Autowired
    private SucursalService sucursalService;

    @PostMapping
    public Sucursal crear(@RequestBody Sucursal sucursal)
    {
        return sucursalService.guardarSucursal(sucursal);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Sucursal> obtenerSucursal(@PathVariable Integer id) 
    {
        Sucursal sucursal = sucursalService.buscarPorId(id);

        return sucursal != null
            ? ResponseEntity.ok(sucursal)
            : ResponseEntity.notFound().build();
    }

    @GetMapping
    public List<Sucursal> listar() 
    {
        return sucursalService.listarTodo();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) 
    {
        sucursalService.eliminarSucursal(id);

        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Sucursal> actualizar(@PathVariable Integer id, @RequestBody Sucursal sucursalActualizada) 
    {
        Sucursal sucursalExistente = sucursalService.buscarPorId(id);

        if (sucursalExistente == null) 
        {
            return ResponseEntity.notFound().build();
        }

        if (sucursalActualizada.getNombreRecinto() != null) 
        {
            sucursalExistente.setNombreRecinto(sucursalActualizada.getNombreRecinto());
        }

        if (sucursalActualizada.getDireccion() != null) 
        {
            sucursalExistente.setDireccion(sucursalActualizada.getDireccion());
        }

        if (sucursalActualizada.getCodComuna() != null) 
        {
            sucursalExistente.setCodComuna(sucursalActualizada.getCodComuna());
        }

        Sucursal guardada = sucursalService.guardarSucursal(sucursalExistente);

        return ResponseEntity.ok(guardada);
    }
}
