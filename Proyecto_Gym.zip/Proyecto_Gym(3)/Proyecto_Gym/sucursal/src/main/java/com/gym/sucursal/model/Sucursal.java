package com.gym.sucursal.model;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "sucursal")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Sucursal 
{
@Id
    private Integer codSucursal;

    private String nombreRecinto;
    private String direccion;
    private Integer codComuna;

    @Transient
    private Object datosUbicacion;
}
