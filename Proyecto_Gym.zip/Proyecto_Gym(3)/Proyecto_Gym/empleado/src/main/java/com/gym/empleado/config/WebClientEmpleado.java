package com.gym.empleado.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientEmpleado
{
@Bean
    public WebClient.Builder WebClientBuilder()
    {
        return WebClient.builder();
    }
}
