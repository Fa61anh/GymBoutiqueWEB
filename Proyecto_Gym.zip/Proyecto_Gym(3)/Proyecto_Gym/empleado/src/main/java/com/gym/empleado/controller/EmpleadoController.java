package com.gym.empleado.controller;
import com.gym.empleado.model.Empleado;
import com.gym.empleado.service.EmpleadoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/empleados/")
public class EmpleadoController 
{
 @Autowired
    private EmpleadoService empleadoService;

    @PostMapping
    public Empleado crear(@RequestBody Empleado empleado)
    {
        return empleadoService.guardarEmpleado(empleado);
    }

    @GetMapping("/{run}")
    public ResponseEntity<Empleado> obtenerEmpleado(@PathVariable String run) 
    {
        Empleado empleado = empleadoService.buscarPorRun(run);

        return empleado != null
            ? ResponseEntity.ok(empleado)
            : ResponseEntity.notFound().build();
    }

    @GetMapping
    public List<Empleado> listar() 
    {
        return empleadoService.listarTodo();
    }

    @DeleteMapping("/{run}")
    public ResponseEntity<Void> eliminar(@PathVariable String run) 
    {
        empleadoService.eliminarEmpleado(run);

        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{run}")
    public ResponseEntity<Empleado> actualizar(@PathVariable String run, @RequestBody Empleado empleadoActualizado) 
    {
        Empleado empleadoExistente = empleadoService.buscarPorRun(run);

        if (empleadoExistente == null) 
        {
            return ResponseEntity.notFound().build();
        }

        if (empleadoActualizado.getNomb() != null) 
        {
            empleadoExistente.setNomb(empleadoActualizado.getNomb());
        }

        if (empleadoActualizado.getApell() != null) 
        {
            empleadoExistente.setApell(empleadoActualizado.getApell());
        }

        if (empleadoActualizado.getNumero() != null) 
        {
            empleadoExistente.setNumero(empleadoActualizado.getNumero());
        }

        if (empleadoActualizado.getCorreo() != null) 
        {
            empleadoExistente.setCorreo(empleadoActualizado.getCorreo());
        }

        if (empleadoActualizado.getTipoEmpleado() != null) 
        {
            empleadoExistente.setTipoEmpleado(empleadoActualizado.getTipoEmpleado());
        }

        if (empleadoActualizado.getCodSucursal() != null) 
        {
            empleadoExistente.setCodSucursal(empleadoActualizado.getCodSucursal());
        }

        Empleado guardado = empleadoService.guardarEmpleado(empleadoExistente);

        return ResponseEntity.ok(guardado);
    }
}
