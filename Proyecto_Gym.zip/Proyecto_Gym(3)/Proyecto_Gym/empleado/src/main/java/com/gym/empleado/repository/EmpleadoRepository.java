package com.gym.empleado.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gym.empleado.model.Empleado;

@Repository
public interface EmpleadoRepository extends JpaRepository<Empleado, String>
 {

}
