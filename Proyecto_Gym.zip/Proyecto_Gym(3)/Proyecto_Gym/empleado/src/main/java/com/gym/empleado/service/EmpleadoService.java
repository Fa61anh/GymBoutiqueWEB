package com.gym.empleado.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.gym.empleado.model.Empleado;
import com.gym.empleado.repository.EmpleadoRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class EmpleadoService 
{
 @Autowired
    private EmpleadoRepository rp;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public Empleado guardarEmpleado(Empleado empleado) 
{
    Object sucursal;

    try 
    {
        sucursal = webClientBuilder.build()
            .get()
            .uri("http://localhost:9089/api/v1/sucursales/" + empleado.getCodSucursal())
            .retrieve()
            .bodyToMono(Object.class)
            .block();

        if (sucursal == null) 
        {
            throw new RuntimeException("Sucursal no existe");
        }
    } 
    catch (Exception e) 
    {
        throw new RuntimeException("Error de validación: " + e.getMessage());
    }

    Empleado guardado = rp.save(empleado);
    guardado.setDatosSucursal(sucursal);

    return guardado;
}

    public Empleado buscarPorRun(String run) 
    {
        Empleado empleado = rp.findById(run).orElse(null);

        if (empleado != null) 
        {
            return enriquecerEmpleado(empleado);
        }

        return null;
    }

    private Empleado enriquecerEmpleado(Empleado empleado) 
    {
        try 
        {
            Object sucursal = webClientBuilder.build()
                .get()
                .uri("http://localhost:9089/api/v1/sucursales/" + empleado.getCodSucursal())
                .retrieve()
                .bodyToMono(Object.class)
                .block();

            empleado.setDatosSucursal(sucursal);

        } 
        catch (Exception e) 
        {
            System.err.println("Error enriqueciendo empleado: " + e.getMessage());
        }

        return empleado;
    }

    public List<Empleado> listarTodo() 
    {
        List<Empleado> lista = rp.findAll();

        return lista.stream()
            .map(this::enriquecerEmpleado)
            .toList();
    }

    public void eliminarEmpleado(String run) 
    {
        rp.deleteById(run);
    }
}
