package com.gym.empleado.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SucursalDTO {
    private Integer codSucursal;
    private String nombreRecinto;
    private String direccion;
}
