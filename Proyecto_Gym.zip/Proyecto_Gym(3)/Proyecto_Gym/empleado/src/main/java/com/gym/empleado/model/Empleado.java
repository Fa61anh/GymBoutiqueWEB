package com.gym.empleado.model;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "empleados")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Empleado 
{
    @Id
    @Column(unique = true, name = "rut", length = 10, nullable = false)
    private String run;

    @Column(unique = false, name = "nombres", length = 100, nullable = false)
    private String nomb;

    @Column(unique = false, name = "apellidos", length = 100, nullable = false)
    private String apell;

    @Column(unique = true, length = 100, nullable = false)
    private String correo;

    @Column(unique = true, name = "numero_celular", length = 15, nullable = false)
    private String numero;

    @Column(unique = true, name = "numero_celular_respaldo", length = 15, nullable = false)
    private String numrespaldo;

    @Column(name = "fecha_nacimiento")
    private LocalDate fechaNacimiento;

    @Column(name = "tipo_empleado", length = 50, nullable = false)
    private String tipoEmpleado;

    @Column(name = "cod_sucursal", nullable = false)
    private Integer codSucursal;

    @Transient
    private Object datosSucursal;
}
