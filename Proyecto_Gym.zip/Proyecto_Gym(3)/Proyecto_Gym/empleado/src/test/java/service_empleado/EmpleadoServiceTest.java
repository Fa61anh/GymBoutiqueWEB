package service_empleado;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.gym.empleado.model.Empleado;
import com.gym.empleado.model.SucursalDTO;
import com.gym.empleado.repository.EmpleadoRepository;
import com.gym.empleado.service.EmpleadoService;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class EmpleadoServiceTest {
    @Mock
    private EmpleadoRepository empleadoRepository;
    @Mock
    private WebClient.Builder webClientBuilder;
    @InjectMocks
    private EmpleadoService empleadoService;
    @Test
    void obtenerSucursalCompletaTest(){
        Integer sucursalId = 963;
        String empleadoId = "12345678-9";


        Empleado empleadoMock = new Empleado();
        empleadoMock.setRun(empleadoId);
        empleadoMock.setCodSucursal(sucursalId);

        SucursalDTO sucursalMock = new SucursalDTO();
        sucursalMock.setCodSucursal(sucursalId);
        sucursalMock.setNombreRecinto("Recinto Principal");

        when(empleadoRepository.findById(empleadoId)).thenReturn(Optional.of(empleadoMock));

        WebClient webClient = Mockito.mock(WebClient.class);
        WebClient.RequestHeadersUriSpec uriSpec = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec headersSpec = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpec = Mockito.mock(WebClient.ResponseSpec.class);
 
        when(webClientBuilder.build()).thenReturn(webClient);
        when(webClient.get()).thenReturn(uriSpec);
        when(uriSpec.uri(anyString())).thenReturn(headersSpec);
        when(headersSpec.retrieve()).thenReturn(responseSpec);
        
        when(responseSpec.bodyToMono(Object.class)).thenReturn(Mono.just(sucursalMock));

    
        Empleado resultado = empleadoService.buscarPorRun(empleadoId);
        assertNotNull(resultado, "El empleado no debe ser nulo");
        assertNotNull(resultado.getDatosSucursal(), "Los datos de la sucursal deben estar presentes");
        
    
        SucursalDTO datosRetornados = (SucursalDTO) resultado.getDatosSucursal();
        assertEquals("Recinto Principal", datosRetornados.getNombreRecinto(), "El nombre del recinto debe coincidir con el simulado");
        assertEquals(sucursalId, datosRetornados.getCodSucursal());

        verify(empleadoRepository, times(1)).findById(empleadoId);
    }

}
