package com.gym.inscripciones.service;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import com.gym.inscripciones.model.Inscripciones;
import com.gym.inscripciones.repository.InscripcionesRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class InscripcionesService 
{
    @Autowired
    private InscripcionesRepository rp;
    @Autowired
    private WebClient.Builder webClientBuilder;
    
    public Inscripciones guardarInscripcion(Inscripciones inscripcion) 
    {
    if (inscripcion.getCod_inscripcion() == null) {
        inscripcion.setFechaInscripcion(LocalDate.now());
        inscripcion.setEstado_inscripcion("CONFIRMADA");
    }

    try 
    {
        // ALUMNO (POR GATEWAY)
        Object alumno = webClientBuilder.build()
            .get()
            .uri("http://localhost:9097/api/v1/alumnos/" + inscripcion.getId_alumno())
            .retrieve()
            .bodyToMono(Object.class)
            .block();

        if (alumno == null) {
            throw new RuntimeException("Alumno no existe");
        }

        // CLASE
        Object clase = webClientBuilder.build()
            .get()
            .uri("http://localhost:9093/api/v1/clases/" + inscripcion.getId_clase())
            .retrieve()
            .bodyToMono(Object.class)
            .block();

        if (clase == null) {
            throw new RuntimeException("Clase no existe");
        }

    } 
    catch (Exception e) 
    {
        throw new RuntimeException("Error de validación: " + e.getMessage());
    }

    return rp.save(inscripcion);
    }

    public Inscripciones obtenerDetalleInscripcion(Integer id) {
        Inscripciones inscripcion = rp.findById(id).orElse(null);
        if (inscripcion != null) {
            return enriquecerInscripciones(inscripcion);
        }
        return null;
    }

    private Inscripciones enriquecerInscripciones(Inscripciones inscripcion) {
    try {

        Object alumno = webClientBuilder.build().get()
            .uri("http://localhost:9097/api/v1/alumnos/" + inscripcion.getId_alumno())
            .retrieve().bodyToMono(Object.class).block();

        inscripcion.setDatosAlumno(alumno);

        Object clase = webClientBuilder.build().get()
            .uri("http://localhost:9093/api/v1/clases/" + inscripcion.getId_clase())
            .retrieve().bodyToMono(Object.class).block();

        inscripcion.setDatosClase(clase);

       

    } catch (Exception e) {
        System.err.println("Error enriqueciendo: " + e.getMessage());
    }

    return inscripcion;
    }

    public List<Inscripciones> listarTodas() {
        return rp.findAll();
    }

    public List<Inscripciones> listarTodo() {

    List<Inscripciones> lista = rp.findAll();

    return lista.stream()
        .map(this::enriquecerInscripciones)
        .toList();
    }

    public void eliminarInscripcion(Integer id) {
        rp.deleteById(id);
    }
}


