package com.gym.inscripciones.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gym.inscripciones.model.Inscripciones;

@Repository
public interface InscripcionesRepository extends JpaRepository<Inscripciones, Integer>
{

}
