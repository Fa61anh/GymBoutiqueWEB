package com.gym.inscripciones.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gym.inscripciones.model.Inscripciones;
import com.gym.inscripciones.service.InscripcionesService;

@RestController
@RequestMapping("/api/v1/inscripciones/")
public class InscripcionesController 
{
    @Autowired
    private InscripcionesService sr;

    @PostMapping
    public ResponseEntity<?> crearInscripcion(@RequestBody Inscripciones inscripcion) {
        try {
            Inscripciones nueva = sr.guardarInscripcion(inscripcion);
            return ResponseEntity.status(HttpStatus.CREATED).body(nueva);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerDetalle(@PathVariable Integer id) {
        Inscripciones inscripcion = sr.obtenerDetalleInscripcion(id);
        if (inscripcion != null) {
            return ResponseEntity.ok(inscripcion);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Inscripción no encontrada");
    }

    @GetMapping
    public List<Inscripciones> listar() {
        return sr.listarTodo();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        sr.eliminarInscripcion(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/actualizar/{id}")
    public ResponseEntity<Inscripciones> actualizar(@PathVariable Integer id, @RequestBody Inscripciones inscripcionActualizada) {
    Inscripciones inscripcionExistente = sr.obtenerDetalleInscripcion(id);
    
    if (inscripcionExistente == null) {
        return ResponseEntity.notFound().build(); 
    }
    
    inscripcionExistente.setId_alumno(inscripcionActualizada.getId_alumno());
    inscripcionExistente.setId_clase(inscripcionActualizada.getId_clase());
    
    if (inscripcionActualizada.getEstado_inscripcion() != null) {
        inscripcionExistente.setEstado_inscripcion(inscripcionActualizada.getEstado_inscripcion());
    }

    try {
       
        sr.obtenerDetalleInscripcion(id); 
    } catch (Exception e) {
        throw new RuntimeException("Error al validar los nuevos datos de la inscripción: " + e.getMessage());
    }
    
    Inscripciones guardada = sr.guardarInscripcion(inscripcionExistente); 
    
    return ResponseEntity.ok(guardada);
    }
}
