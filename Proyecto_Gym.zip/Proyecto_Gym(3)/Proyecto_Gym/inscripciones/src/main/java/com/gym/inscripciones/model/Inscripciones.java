package com.gym.inscripciones.model;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "inscripciones")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Inscripciones 
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer cod_inscripcion;

    @Column(name = "fecha_inscripcion")
    private LocalDate fechaInscripcion;

    @Column(unique = false, name = "Estado", length = 10, nullable = false)
    private String estado_inscripcion;

    @Column(name = "rut_alumno")
    private String id_alumno;

    @Column(unique = false)
    private Long id_clase;
    
    @Transient
    private Object DatosAlumno;

    @Transient
    private Object DatosClase; 
    
    @Transient
    private Object DatosMembresia;

    


}
