package com.gym.instructor.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "instructor")
@Data

@AllArgsConstructor
@NoArgsConstructor
public class Instructor 
{
    @Id
    @Column(unique = true, name = "run", length = 10, nullable = false)
    private String run;

    @Column(unique = false, name = "nombres", length = 100, nullable = false)
    private String nomb;

    @Column(unique = false, name = "apellidos", length = 100, nullable = false)
    private String apell;

    @Column(unique = true, length = 100, nullable = false)
    private String correo; 

    @Column(unique = true, name = "numero_celular", length = 15, nullable = false)
    private String numero; 

    @Column(unique = false, length = 500, nullable = false)
    private String direccion;

    @ManyToOne
    @JoinColumn(name = "id_tipo")
    private TipoInstructor tipo;

}