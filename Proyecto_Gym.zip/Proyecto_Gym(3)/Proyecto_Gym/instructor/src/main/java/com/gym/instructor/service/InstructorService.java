package com.gym.instructor.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.gym.instructor.model.Instructor;
import com.gym.instructor.model.TipoInstructor;
import com.gym.instructor.repository.InstructorRetository;
import com.gym.instructor.repository.TipoInstructorRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class InstructorService 
{
    @Autowired
    private InstructorRetository instructorRepository;

    @Autowired
    private TipoInstructorRepository tipoRepository;

    public Instructor guardar(Instructor instructor) {

        Long idTipo = instructor.getTipo().getId_tipo();

        TipoInstructor tipo = tipoRepository.findById(idTipo)
                .orElseThrow(() -> new RuntimeException("El tipo de instructor no existe"));

        instructor.setTipo(tipo);

        return instructorRepository.save(instructor);
    }

    public List<Instructor> listar() {
        return instructorRepository.findAll();
    }
    public Instructor buscarPorRun(String run)
    {
    return instructorRepository.findById(run).orElse(null);
    }

    public Instructor actualizar(String run, Instructor instructorActualizado) {
    Instructor existente = instructorRepository.findById(run)
            .orElseThrow(() -> new RuntimeException("Instructor no encontrado"));

    TipoInstructor tipo = tipoRepository.findById(instructorActualizado.getTipo().getId_tipo())
            .orElseThrow(() -> new RuntimeException("El tipo de instructor no existe"));

    existente.setNomb(instructorActualizado.getNomb());
    existente.setApell(instructorActualizado.getApell());
    existente.setCorreo(instructorActualizado.getCorreo());
    existente.setNumero(instructorActualizado.getNumero());
    existente.setDireccion(instructorActualizado.getDireccion());
    existente.setTipo(tipo);

    return instructorRepository.save(existente);
   }

     public void eliminar(String run) {
    instructorRepository.deleteById(run);
    }

}
