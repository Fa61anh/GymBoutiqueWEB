package com.gym.instructor.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.gym.instructor.model.TipoInstructor;

@Repository
public interface TipoInstructorRepository extends JpaRepository<TipoInstructor,Long>
{

}
