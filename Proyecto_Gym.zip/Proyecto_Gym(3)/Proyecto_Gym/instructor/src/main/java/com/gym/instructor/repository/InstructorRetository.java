package com.gym.instructor.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.gym.instructor.model.Instructor;

public interface InstructorRetository extends JpaRepository<Instructor,String>
{


}
