package com.gym.instructor.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor

@Table(name = "tipo_instructor")
public class TipoInstructor 
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
     private Long id_tipo;
    @Column(unique = false, name = "nombre_especialidad", length = 100, nullable = false)
    private String nomb;
}
