package com.gym.instructor.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.gym.instructor.model.Instructor;
import com.gym.instructor.service.InstructorService;

@RestController
@RequestMapping("/api/v1/instructor/")
public class InstructorController
{
@Autowired
    private InstructorService service;

    @GetMapping
    public ResponseEntity<List<Instructor>> listar()
    {
        List<Instructor> alumnos = service.listar();
        return new ResponseEntity<>(alumnos, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Instructor> crear (@RequestBody Instructor instructor)
    {
        return new ResponseEntity<>(service.guardar(instructor),HttpStatus.CREATED);
    }
    
    @GetMapping("/{run}")
    public ResponseEntity<Instructor> obtenerPorRun(@PathVariable String run)
    {
        Instructor alumnos = service.buscarPorRun(run);
        if(alumnos == null) 
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(alumnos,HttpStatus.OK);
    }
 
    @PutMapping("/{run}")
    public ResponseEntity<Instructor> actualizar(@PathVariable String run, @RequestBody Instructor instructor)
    {
    Instructor existente = service.buscarPorRun(run);

    if(existente == null)
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);

    Instructor actualizado = service.actualizar(run, instructor);

    return new ResponseEntity<>(actualizado, HttpStatus.OK);
    }


    @DeleteMapping("/{run}")
    public ResponseEntity<Void> eliminar(@PathVariable String run)
    {
        service.eliminar(run);;
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
