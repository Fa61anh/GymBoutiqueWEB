package com.gym.instructor.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gym.instructor.model.TipoInstructor;
import com.gym.instructor.repository.TipoInstructorRepository;

@RestController
@RequestMapping("/api/v1/instructor/tipos")
public class TipoInstructorConstroller 
{
   @Autowired
    private TipoInstructorRepository repository;

    @GetMapping
    public List<TipoInstructor> listar() {
        return repository.findAll();
    }

    @PostMapping
    public TipoInstructor crear(@RequestBody TipoInstructor tipo) {
        return repository.save(tipo);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
    repository.deleteById(id);
    return ResponseEntity.noContent().build();
    }


}
